package com.example.e5_application.model;

public class Chantier{
    private int id;
    private String nom;
    private String adresse;
    private String date;
    private String prixtt;
    private String ferraillage;
    private String isolation;
    private String plaquage;
    private String jointure;

    public Chantier(int id, String nom, String adresse, String date, String prixtt, String ferraillage, String isolation, String plaquage, String jointure) {
        this.id = id;
        this.nom = nom;
        this.adresse = adresse;
        this.date = date;
        this.prixtt = prixtt;
        this.ferraillage = ferraillage;
        this.isolation = isolation;
        this.plaquage = plaquage;
        this.jointure = jointure;
    }

    public String getJointure() {
        return jointure;
    }

    public void setJointure(String jointure) {
        this.jointure = jointure;
    }

    public String getPlaquage() {
        return plaquage;
    }

    public void setPlaquage(String plasuage) {
        this.plaquage = plasuage;
    }

    public String getIsolation() {
        return isolation;
    }

    public void setIsolation(String isolation) {
        this.isolation = isolation;
    }

    public String getFerraillage() {
        return ferraillage;
    }

    public void setFerraillage(String ferraillage) {
        this.ferraillage = ferraillage;
    }

    public String getPrixtt() {
        return prixtt;
    }

    public void setPrixtt(String prixtt) {
        this.prixtt = prixtt;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getAdresse() {
        return adresse;
    }

    public void setAdresse(String adresse) {
        this.adresse = adresse;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public int getId() {
        return id;
    }

    @Override
    public String toString(){
        String chaine = nom + " " + adresse + " " + date + " " + prixtt;
        return chaine;
    }
}
