package com.example.e5_application.controller;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.e5_application.R;
import com.example.e5_application.controller.MainActivity;

public class PreferenceActivity extends AppCompatActivity {
    private EditText editPrixFer;
    private EditText editPrixIso;
    private EditText editPrixPlaco;
    private EditText editPrixJoint;
    private Button btSauvegarder;
    private Button btAnnuler;

    private String namePreference = "calculePreference";

    private void init(){
        editPrixFer = findViewById(R.id.editPrixFer);
        editPrixIso = findViewById(R.id.editPrixIso);
        editPrixPlaco = findViewById(R.id.editPrixPlaco);
        editPrixJoint = findViewById(R.id.editPrixJoint);
        btSauvegarder = findViewById(R.id.btSauvegarder);
        btAnnuler = findViewById(R.id.btAnnuler);

        SharedPreferences prixPref = getApplicationContext().getSharedPreferences(namePreference, 0); // 0 - for private mode
        SharedPreferences.Editor editor = prixPref.edit();
        Integer prixFer = prixPref.getInt("prixFer", 0);
        Integer prixIso = prixPref.getInt("prixIso", 0);
        Integer prixPlaco = prixPref.getInt("prixPlaco", 0);
        Integer prixJoint = prixPref.getInt("prixJoint", 0);

        editPrixFer.setText(prixFer.toString());
        editPrixIso.setText(prixIso.toString());
        editPrixPlaco.setText(prixPlaco.toString());
        editPrixJoint.setText(prixJoint.toString());

        btSauvegarder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                editor.putInt("prixFer", Integer.parseInt(editPrixFer.getText().toString()));
                editor.putInt("prixIso", Integer.parseInt(editPrixIso.getText().toString()));
                editor.putInt("prixPlaco", Integer.parseInt(editPrixPlaco.getText().toString()));
                editor.putInt("prixJoint", Integer.parseInt(editPrixJoint.getText().toString()));
                editor.commit();
                Intent intent = new Intent(view.getContext(), MainActivity.class);
                startActivity(intent);
                finish();
            }
        });

        btAnnuler.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent2 = new Intent(view.getContext(), MainActivity.class);
                startActivity(intent2);
                // finish();
            }
        });
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_preference);
        init();
    }
}