package com.example.e5_application.controller;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.e5_application.R;
import com.example.e5_application.outils.MySQLiteHelper;

public class NouveauChantier extends AppCompatActivity {

    private TextView txtTotal;
    private EditText nomclient;
    private EditText adresse;
    private EditText date;
    private EditText editFer;
    private EditText editIso;
    private EditText editPlaco;
    private EditText editJoint;
    private Button btCalculer;
    private Button btReset;
    private Button btSettings;
    private Button  btvalidation;
    private Integer total;
    private String namePreference = "calculePreference";

    final MySQLiteHelper myDbHelper = new MySQLiteHelper(this);

    public void init(){
        nomclient = findViewById(R.id.nomClientModifier);
        adresse = findViewById(R.id.adresseModifier);
        date = findViewById(R.id.dateModifier);

        txtTotal = findViewById(R.id.txtTotalModifier);
        editFer = findViewById(R.id.editFerModifier);
        editIso = findViewById(R.id.editIsoModifier);
        editJoint = findViewById(R.id.editJointModifier);
        editPlaco = findViewById(R.id.editPlacoModifier);
        btCalculer = findViewById(R.id.btCalculerModifier);
        btReset = findViewById(R.id.btReset);
        btSettings = findViewById(R.id.btSettings);
        btvalidation = findViewById(R.id.btn_validationModifier);
        txtTotal.setText("0€");

        SharedPreferences pref = getApplicationContext().getSharedPreferences(namePreference, MODE_PRIVATE);




        btCalculer.setOnClickListener(new View.OnClickListener() {
            @Override
            //calcul 4
            public void onClick(View view) {
                total = 0;
                if(!TextUtils.isEmpty(editFer.getText().toString())){
                    total = total + (pref.getInt("prixFer", 0) * Integer.parseInt(editFer.getText().toString()));
                }
                if(!TextUtils.isEmpty(editIso.getText().toString())){
                    total = total + (pref.getInt("prixIso", 0) * Integer.parseInt(editIso.getText().toString()));
                }
                if(!TextUtils.isEmpty(editPlaco.getText().toString())){
                    total = total + (pref.getInt("prixPlaco", 0) * Integer.parseInt(editPlaco.getText().toString()));
                }
                if(!TextUtils.isEmpty(editJoint.getText().toString())){
                    total = total + (pref.getInt("prixJoint", 0) * Integer.parseInt(editJoint.getText().toString()));
                }
                txtTotal.setText(total.toString());
            }
        });

        btReset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                editFer.setText("");
                editIso.setText("");
                editJoint.setText("");
                editPlaco.setText("");
                txtTotal.setText("0€");
                editFer.requestFocus();
            }
        });

        btSettings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent2 = new Intent(view.getContext(), PreferenceActivity.class);
                startActivity(intent2);
                // finish();
            }
        });

        btvalidation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nomnclient1= nomclient.getText().toString();
                String adresse1=adresse.getText().toString();
                String date1 =date.getText().toString();
                String editfer1=editFer.getText().toString();
                String editIso1= editIso.getText().toString();
                String editPlaco1=editPlaco.getText().toString();
                String editJoint1=editJoint.getText().toString();
                String txtTotal1 = txtTotal.getText().toString();

                myDbHelper.AjouterChantier(nomnclient1,adresse1,date1 ,editfer1,txtTotal1 ,editIso1, editPlaco1,editJoint1);
                Log.i("test","test ajout chantier");
                Intent intent = new Intent(v.getContext(), MainActivity.class);
                startActivity(intent);
            }
        });

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nouveau_chantier);
        init();
    }
}