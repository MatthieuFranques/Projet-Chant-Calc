package com.example.e5_application.controller;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import com.example.e5_application.R;
import com.example.e5_application.model.Chantier;
import com.example.e5_application.model.ToutChantier;
import com.example.e5_application.outils.MySQLiteHelper;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    private Button btAdd;
    private ListView listNomclient;


   private void init(){
       final MySQLiteHelper myDbHelper = new MySQLiteHelper(this);
        btAdd=findViewById(R.id.Ajouter);
       ToutChantier lesChantierEnCours = ToutChantier.getInstance();
       lesChantierEnCours.setLesChantier(myDbHelper.getAllChantier());


      listNomclient = findViewById(R.id.listNomClient);

       ArrayAdapter<Chantier> itemsAdapteur = new ArrayAdapter<Chantier>(this, android.R.layout.simple_list_item_1, lesChantierEnCours.getLesChantier());
       listNomclient.setAdapter(itemsAdapteur);


       btAdd.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
               Intent intent = new Intent(view.getContext(), NouveauChantier.class);
               startActivity(intent);
               init();
           }
       });

        listNomclient.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent intent = new Intent(MainActivity.this, ModifierChantier.class);
                intent.putExtra("index", i);
                startActivity(intent);
                finish();
            }
        });

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        init();





    }
}