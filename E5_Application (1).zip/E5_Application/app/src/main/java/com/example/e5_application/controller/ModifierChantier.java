package com.example.e5_application.controller;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.e5_application.R;
import com.example.e5_application.model.Chantier;
import com.example.e5_application.model.ToutChantier;
import com.example.e5_application.outils.MySQLiteHelper;

public class ModifierChantier extends AppCompatActivity {

    private TextView txtTotalModifier;
    private EditText nomclientModifier;
    private EditText adresseModifier;
    private EditText dateModifier;
    private EditText editFerModifier;
    private EditText editIsoModifier;
    private EditText editPlacoModifier;
    private EditText editJointModifier;
    private Button btCalculerModifier;
    private Button  btvalidationModifier;
    private Button btnDeleteModifier;
    private Integer total;
    private String namePreference = "calculePreference";
    private Chantier chantierSelectionnee;


    private void init(){
        ToutChantier lesChantierEnCours = ToutChantier.getInstance();
        Bundle b = getIntent().getExtras();


        nomclientModifier = findViewById(R.id.nomClientModifier);
        adresseModifier = findViewById(R.id.adresseModifier);
        dateModifier = findViewById(R.id.dateModifier);

        txtTotalModifier = findViewById(R.id.txtTotalModifier);
        editFerModifier = findViewById(R.id.editFerModifier);
        editIsoModifier = findViewById(R.id.editIsoModifier);
        editJointModifier = findViewById(R.id.editJointModifier);
        editPlacoModifier = findViewById(R.id.editPlacoModifier);
        btCalculerModifier = findViewById(R.id.btCalculerModifier);
        btvalidationModifier = findViewById(R.id.btn_validationModifier);
        btnDeleteModifier= findViewById(R.id.btnDeleteModifier);


        SharedPreferences pref = getApplicationContext().getSharedPreferences(namePreference, MODE_PRIVATE);
        if(b!=null){
            int pos = b.getInt("index");
            chantierSelectionnee = lesChantierEnCours.getLesChantier().get(pos);
        }
        final MySQLiteHelper myDbHelper = new MySQLiteHelper(this);
        nomclientModifier.setText(chantierSelectionnee.getNom());
        adresseModifier.setText(chantierSelectionnee.getAdresse());
        dateModifier.setText(chantierSelectionnee.getDate());
        editFerModifier.setText(chantierSelectionnee.getFerraillage());
        editIsoModifier.setText(chantierSelectionnee.getIsolation());
        editJointModifier.setText(chantierSelectionnee.getJointure());
        editPlacoModifier.setText(chantierSelectionnee.getPlaquage());
        txtTotalModifier.setText(chantierSelectionnee.getPrixtt());

        btnDeleteModifier.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int id = chantierSelectionnee.getId();
                myDbHelper.DeleteChantier(id);
                Intent intent = new Intent(view.getContext(), MainActivity.class);
                startActivity(intent);
            }
        });

        btvalidationModifier.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nomnclient= nomclientModifier.getText().toString();
                String adresse=adresseModifier.getText().toString();
                String date =dateModifier.getText().toString();
                String editfer=editFerModifier.getText().toString();
                String editIso= editIsoModifier.getText().toString();
                String editPlaco=editJointModifier.getText().toString();
                String editJoint=editPlacoModifier.getText().toString();
                String txtTotal= txtTotalModifier.getText().toString();
                int id = chantierSelectionnee.getId();
                Log.i("test","test ajout chantier" + id);
                myDbHelper.UpdateChantier(id,nomnclient,adresse,date ,editfer,txtTotal ,editIso, editPlaco,editJoint);

                Intent intent = new Intent(v.getContext(), MainActivity.class);
                startActivity(intent);
            }
        });

        btCalculerModifier.setOnClickListener(new View.OnClickListener() {
            @Override
            //calcul 4
            public void onClick(View view) {
                total = 0;
                if(!TextUtils.isEmpty(editFerModifier.getText().toString())){
                    total = total + (pref.getInt("prixFer", 0) * Integer.parseInt(editFerModifier.getText().toString()));
                }
                if(!TextUtils.isEmpty(editIsoModifier.getText().toString())){
                    total = total + (pref.getInt("prixIso", 0) * Integer.parseInt(editIsoModifier.getText().toString()));
                }
                if(!TextUtils.isEmpty(editPlacoModifier.getText().toString())){
                    total = total + (pref.getInt("prixPlaco", 0) * Integer.parseInt(editPlacoModifier.getText().toString()));
                }
                if(!TextUtils.isEmpty(editJointModifier.getText().toString())){
                    total = total + (pref.getInt("prixJoint", 0) * Integer.parseInt(editJointModifier.getText().toString()));
                }
                txtTotalModifier.setText(total.toString());
            }
        });
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modifier_chantier);
        init();
    }
}