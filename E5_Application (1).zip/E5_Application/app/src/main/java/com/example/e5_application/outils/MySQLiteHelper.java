package com.example.e5_application.outils;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.example.e5_application.model.Chantier;

import java.util.ArrayList;
import java.util.List;

public class MySQLiteHelper extends SQLiteOpenHelper {
    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "bdCalc";

    public MySQLiteHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {


        //table Chantier
        String CREATE_CHANTIER_TABLE = "CREATE TABLE Chantier ( " +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "nomclient TEXT, " +
                "adresse TEXT," +
                "date TEXT," +
                "prixtt TEXT," +
                "ferraillage TEXT, " +
                "isolation TEXT," +
                "plaquage TEXT," +
                "jointure TEXT)";

        db.execSQL(CREATE_CHANTIER_TABLE);
 //valeur Chantier
        db.execSQL("INSERT INTO Chantier VALUES(?,'Franques','Place st Sernin','18/04/2022','325','10','0','15','20')");
        db.execSQL("INSERT INTO Chantier VALUES(?,'Delaplace','Place st Sernin','18/04/2022','325','10','0','15','20')");
        db.execSQL("INSERT INTO Chantier VALUES(?,'Test3','Place st Sernin','18/04/2022','325','10','0','15','20')");



    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS Chantier");
        this.onCreate(db);

    }


    private static final String TABLE_CHANTIER = "Chantier";
    private static final String USERS_KEY_NOMCLIENT = "nomclient";
    private static final String USERS_KEY_ADRESSE = "adresse";
    private static final String USERS_KEY_DATE = "date";
    private static final String USERS_KEY_PRIX = "prixtt";



    public void AjouterChantier(String nomnclient1, String adresse1, String date1, String editfer1, String txtTotal1, String editIso1, String editPlaco1, String editJoint1) {
        String SQL = "INSERT INTO Chantier(nomclient,adresse,date,prixtt,ferraillage,isolation,plaquage,jointure)  VALUES ('"+nomnclient1+"', '"+adresse1+"', '"+date1+"', '"+txtTotal1+"', '"+editfer1+"', '"+editIso1+"', '"+editPlaco1+"' , '"+editJoint1+"');";
        this.getWritableDatabase().execSQL(SQL);
        Log.i("DATABASE", " Insert Chantier invoked");
    }


    public List<Chantier> getAllChantier() {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor mCursor = db.rawQuery("SELECT * FROM " + TABLE_CHANTIER +";", new String[]{});
        List<Chantier> lesChantiers = new ArrayList<Chantier>();
        if (mCursor != null) {
            mCursor.moveToFirst();
            while(!mCursor.isAfterLast()){
                int a = Integer.parseInt(mCursor.getString(0));
                Chantier chantier = new Chantier(a,mCursor.getString(1),mCursor.getString(2),mCursor.getString(3),mCursor.getString(4),mCursor.getString(5),mCursor.getString(6),mCursor.getString(7),mCursor.getString(8));
                lesChantiers.add(chantier);
                mCursor.moveToNext();
            }
            return lesChantiers;
        }
        else{
            return null;
        }
    }

    public void UpdateChantier(int id, String nomnclient, String adresse, String date, String editfer, String txtTotal, String editIso, String editPlaco, String editJoint){
        String SQL = "UPDATE Chantier SET nomclient = '"+nomnclient+"',adresse = '"+adresse+"', date = '"+date+"', prixtt = '"+txtTotal+"', ferraillage = '"+editfer+"', isolation = '"+editIso+"', plaquage = '"+editPlaco+"', jointure = '"+editJoint+"' WHERE id = "+id+";";
        this.getWritableDatabase().execSQL(SQL);
        Log.i("DATABASE", " Update Chantier invoked");
    }

    public void DeleteChantier(int id){
        String SQL ="DELETE FROM Chantier Where id ="+id+";";
                this.getWritableDatabase().execSQL(SQL);
        Log.i("DATABASE", " Delte Chantier invoked");
    }










}
