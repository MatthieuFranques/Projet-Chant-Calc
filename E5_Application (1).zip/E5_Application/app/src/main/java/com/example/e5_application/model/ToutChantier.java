package com.example.e5_application.model;

import java.util.List;

public class ToutChantier {
    private static ToutChantier instance = null;
    private Long dateActuel;
    private List<Chantier> lesChantier;

    public ToutChantier(Long dateActuel) {
        this.dateActuel = dateActuel;
    }

    public static ToutChantier getInstance() {
        if(ToutChantier.instance == null){
            synchronized (ToutChantier.class){
                if(ToutChantier.instance == null){
                    ToutChantier.instance = new ToutChantier(new java.util.Date().getTime());
                }
            }
        }
        return ToutChantier.instance;
    }


    public List<Chantier> getLesChantier() {
        return lesChantier;
    }

    public void setLesChantier(List<Chantier> lesChantier) {
        this.lesChantier = lesChantier;
    }

    public Long getDateActuel() {
        return dateActuel;
    }
}
